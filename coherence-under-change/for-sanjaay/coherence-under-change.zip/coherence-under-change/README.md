# Coherence Under Change

Measures how quickly an LLM breaks earlier network policy while applying a long sequence of config edits, and
prevents it with a pre-commit guard. Track A (test bed, checker, harness, guard core) plus the sequence generator,
the real-model runner and the fine-tuning data.

## What is real and what is simulated
- **Judge.** `cuc/engine.py` is a Python reference engine for the Cisco-IOS-style subset used here (OSPF with
  interface costs and ECMP, interface ACLs, OSPF inbound prefix-list filters, VRFs). `cuc/batfish_backend.py` runs
  the same checks on real Batfish. The two are cross-checked by the `scripts/validate_*` scripts (results below).
  Model runs use the reference engine as the judge, because Batfish takes seconds per snapshot.
- **Models.** `SimModel` is a seeded simulated LLM with set error rates: its numbers demonstrate the pipeline,
  not real LLM behaviour. Real models run through `cuc/llm.py` (Hugging Face on a GPU, or any OpenAI-compatible
  endpoint) via `scripts/run_models.py` and `notebooks/colab_runs.ipynb`.

## Test beds (`cuc/testbed.py`)
| bed | source | devices | invariants | notes |
|---|---|---|---|---|
| legacy9 | hand-built | 9 | 15 | frozen sequences in `sequences/` (seeds 100-119) |
| abilene | Topology Zoo `Abilene.gml`, 11 core routers | 17 | 20 | training bed |
| bteurope | Topology Zoo `BtEurope.gml`, 24 core routers | 32 | 20 | training bed |
| cesnet | Topology Zoo `Cesnet201006.gml`, 52 core routers | 62 | 20 | held-out test bed |

Every Zoo node is a core router (OSPF area 0, /30 links). Edge routers E1..Ek hang off spread-out core nodes, each
with a host /24 (ACL on the host interface) and a guest /24 (10.2.k.0/24); one more host subnet sits behind a
firewall FW. All ACLs sit on leaf devices, so equal-cost routing cannot make the two engines disagree.

## Intent types (`cuc/intents.py`)
| type | what the gold patch does | trap variants (labelled automatically) |
|---|---|---|
| acl_permit / acl_deny | add an ACL line (deny goes before the catch-all permit) | `prefix_overlap` (rule too broad), `shadowing` (wrong position) |
| prefix_filter | inbound OSPF `distribute-list prefix` on the source's edge router + trailing permit-all | `prefix_overlap`, `implicit_deny` (no permit-all), `shadowing` |
| waypoint | raise OSPF costs (both ends of a link) until every equal-cost path crosses router W | `cost_wrong_end`, `over_steering` |
| vrf_isolate | move a guest network into VRF GUEST (no route in or out) | `isolation_leak` (wrong interface), `over_isolation` (uplink too) |

On the Zoo beds a step's type is drawn from a target mix (40% permit, 15% each of the others) and an intent whose
policy already holds before the edit is discarded. The legacy generator is unchanged (byte-identical sequences).

## Conditions (`cuc/harness.py`)
C0 open loop · C1 counterexample feedback + 3 retries · C2 = C1 + the prompt lists the policies whose dependencies
touch the devices being edited · C3 full guard: commit only if it parses, breaks nothing tracked and achieves the
intent, else roll back (REJECTED); prompt carries the verified-state ledger.

## Validation scripts (need Batfish: `docker run -d --name batfish -p 8888:8888 -p 9997:9997 -p 9996:9996 batfish/allinone`)
    python3 scripts/validate_against_batfish.py           # legacy bed: 30 oracle cases
    python3 scripts/validate_zoo_batfish.py 4             # Zoo beds: baseline + sampled generated edits
    python3 scripts/validate_zoo_batfish.py 3 wp vrf      # only waypoint and VRF intents
    python3 scripts/validate_zoo_mutations.py 3           # 31 breaking edits per bed, all intent types
    python3 scripts/validate_depmap_batfish.py            # dependency map from Batfish traceroute vs reference
Each script also runs without Batfish for the reference side (`--ref-only` where offered).

## Model runs (Colab, see `notebooks/colab_runs.ipynb`)
    python3 scripts/run_models.py --backend hf --model Qwen/Qwen2.5-Coder-7B-Instruct --name qwen7b \
        --bed abilene --seeds 100-102 --length 15 --conds C0,C1,C2,C3 --workers 3 --out RUNS_DIR
    python3 scripts/summarize_runs.py RUNS_DIR             # table + paired bootstrap between conditions
    python3 scripts/make_sft_data.py                       # QLoRA data from training beds + leakage check

## Other scripts
    python3 -m unittest discover -s tests                  # 25 tests
    python3 scripts/run_oracle.py | smoke_test.py          # legacy oracle and smoke test
    N_SEQ=20 LENGTH=100 python3 scripts/run_experiment.py  # simulated models (TESTBED=abilene|bteurope|cesnet)
    python3 scripts/measure_depmap.py 5 60                 # dependency-map misses and savings, simulated model
    python3 scripts/build_testbeds.py                      # write each bed's configs + invariants to testbeds/
